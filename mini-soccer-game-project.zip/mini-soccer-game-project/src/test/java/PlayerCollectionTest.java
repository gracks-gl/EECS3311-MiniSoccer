import model.players.GamePlayer;
import model.players.Goalkeeper;
import model.players.PlayerCollection;
import org.junit.jupiter.api.Test;

import java.awt.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PlayerCollectionTest {
    @Test
    void getTest() {
        PlayerCollection playerCollection = new PlayerCollection();
        GamePlayer gamePlayer1 = new Goalkeeper("name-1", Color.BLACK);
        playerCollection.add(gamePlayer1);
        GamePlayer gamePlayer2 = new Goalkeeper("name-2", Color.YELLOW);
        playerCollection.add(gamePlayer2);
        GamePlayer gamePlayer3 = new Goalkeeper("name-3", Color.GRAY);
        playerCollection.add(gamePlayer3);
        assertEquals(gamePlayer3, playerCollection.get("name-3"));

    }
    @Test
    void addTest() {
        PlayerCollection playerCollection = new PlayerCollection();
        GamePlayer gamePlayer1 = new Goalkeeper("name-1", Color.BLACK);
        playerCollection.add(gamePlayer1);
        GamePlayer gamePlayer2 = new Goalkeeper("name-2", Color.YELLOW);
        playerCollection.add(gamePlayer2);
        GamePlayer gamePlayer3 = new Goalkeeper("name-3", Color.GRAY);
        playerCollection.add(gamePlayer3);
        assertEquals(3, playerCollection.size());

    }
    @Test
    void removeTest() {
        PlayerCollection playerCollection = new PlayerCollection();
        GamePlayer gamePlayer1 = new Goalkeeper("name-1", Color.BLACK);
        playerCollection.add(gamePlayer1);
        GamePlayer gamePlayer2 = new Goalkeeper("name-2", Color.YELLOW);
        playerCollection.add(gamePlayer2);
        GamePlayer gamePlayer3 = new Goalkeeper("name-3", Color.GRAY);
        playerCollection.add(gamePlayer3);
        playerCollection.remove(gamePlayer1);
        assertEquals(2, playerCollection.size());

    }
}
