import model.players.Goalkeeper;
import org.junit.jupiter.api.Test;

import java.awt.*;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class GoalKeeperTest {
    @Test
    void moveLeftTest() {
        Goalkeeper goalkeeper = new Goalkeeper("name", Color.BLACK);
        goalkeeper.getPlayerPosition().x=0;
        int x=0;
        int y = goalkeeper.getPlayerPosition().y;
        goalkeeper.moveLeft();
        assertEquals(x,goalkeeper.getPlayerPosition().x);
        assertEquals(y,goalkeeper.getPlayerPosition().y);

    }
    @Test
    void moveUpTest() {
        Goalkeeper goalkeeper = new Goalkeeper("name", Color.BLACK);
        goalkeeper.getPlayerPosition().y=0;
        int x=goalkeeper.getPlayerPosition().x;
        int y = 0;
        goalkeeper.moveUp();
        assertEquals(x,goalkeeper.getPlayerPosition().x);
        assertEquals(y,goalkeeper.getPlayerPosition().y);

    }

}
