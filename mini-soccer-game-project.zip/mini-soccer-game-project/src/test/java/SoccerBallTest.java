import model.SoccerBall;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class SoccerBallTest {
    @Test
    void resetSoccerBallTest() {
        SoccerBall soccerBall =SoccerBall.getSoccerBall();
        soccerBall.resetSoccerBall();
        assertEquals(0.0,soccerBall.getVelocity());

    }
}
