import model.players.GamePlayer;
import model.players.Goalkeeper;
import model.players.PlayerCollection;
import model.players.PlayerCollectionIterator;
import org.junit.jupiter.api.Test;

import java.awt.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PlayerCollectionIteratorTest {
    @Test
    void nextTest() {
        PlayerCollection playerCollection = new PlayerCollection();
        GamePlayer gamePlayer1 = new Goalkeeper("name-1", Color.BLACK);
        playerCollection.add(gamePlayer1);
        GamePlayer gamePlayer2 = new Goalkeeper("name-2", Color.YELLOW);
        playerCollection.add(gamePlayer2);
        GamePlayer gamePlayer3 = new Goalkeeper("name-3", Color.GRAY);
        playerCollection.add(gamePlayer3);
        PlayerCollectionIterator playerCollectionIterator = new PlayerCollectionIterator(playerCollection);
        playerCollectionIterator.next();
        assertEquals(gamePlayer2,playerCollectionIterator.next());
    }

    @Test
    void hasNextTest() {
        PlayerCollection playerCollection = new PlayerCollection();
        GamePlayer gamePlayer1 = new Goalkeeper("name-1", Color.BLACK);
        playerCollection.add(gamePlayer1);
        GamePlayer gamePlayer2 = new Goalkeeper("name-2", Color.YELLOW);
        playerCollection.add(gamePlayer2);
        GamePlayer gamePlayer3 = new Goalkeeper("name-3", Color.GRAY);
        playerCollection.add(gamePlayer3);
        PlayerCollectionIterator playerCollectionIterator = new PlayerCollectionIterator(playerCollection);
        playerCollectionIterator.next();
        assertEquals(true,playerCollectionIterator.hasNext());
    }
    @Test
    void hasNextTest2() {
        PlayerCollection playerCollection = new PlayerCollection();
        GamePlayer gamePlayer1 = new Goalkeeper("name-1", Color.BLACK);
        playerCollection.add(gamePlayer1);
        GamePlayer gamePlayer2 = new Goalkeeper("name-2", Color.YELLOW);
        playerCollection.add(gamePlayer2);
        GamePlayer gamePlayer3 = new Goalkeeper("name-3", Color.GRAY);
        playerCollection.add(gamePlayer3);
        PlayerCollectionIterator playerCollectionIterator = new PlayerCollectionIterator(playerCollection);
        playerCollectionIterator.next();
        playerCollectionIterator.next();
        playerCollectionIterator.next();
        assertEquals(false,playerCollectionIterator.hasNext());
    }

}
