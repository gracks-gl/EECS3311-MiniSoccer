import model.players.GamePlayer;
import model.players.Goalkeeper;
import model.players.PlayerFactory;
import model.players.Striker;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertInstanceOf;


public class PlayerFactoryTest {

    @Test
    void test() {
        PlayerFactory playerFactory = new PlayerFactory();
        GamePlayer goalKeeper = playerFactory.getPlayer("goalkeeper");
        GamePlayer striker = playerFactory.getPlayer("striker");
        assertInstanceOf(Goalkeeper.class, goalKeeper);
        assertInstanceOf(Striker.class, striker);
    }
}
