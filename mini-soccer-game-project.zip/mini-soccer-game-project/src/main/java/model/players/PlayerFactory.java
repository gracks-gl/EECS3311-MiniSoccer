package model.players;

import java.awt.Color;


/**
 * This class implements the Factory Design pattern
 * for the player. It returns two types of players
 * Goalkeeper with color yellow and Striker with color blue
 */
public class PlayerFactory {

	public GamePlayer getPlayer(String playerType) {
		if(playerType.equalsIgnoreCase("GoalKeeper")) 
		{
			
		return new Goalkeeper("Goalkeeper",Color.yellow);
		} 
		
		else if(playerType.equalsIgnoreCase("Striker"))
		{
			
		return new Striker("Striker",Color.blue);
		}
		return null;
	}
}