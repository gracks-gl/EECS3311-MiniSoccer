package model.players;

import model.SoccerBall;

import java.awt.*;

/**
 * This class implements the movement methods for the Striker player
 * The player is moved 5 units either on x-axis or y-axis in
 * either direction
 */
public class Striker extends GamePlayer {
	public Striker(String name, Color color) {
		super(name, color);
	}

	/**
	 * Moves the player up by 5 units
	 */
	@Override
	public void moveUp() {
		if (getPlayerPosition().y - 5 > 200) {
			setPlayerPosition(new Point(getPlayerPosition().x, getPlayerPosition().y - 5));
		}
	}

	/**
	 * moved the player down by 5 units
	 */
	@Override
	public void moveDown() {
		if (getPlayerPosition().y + 50 < 500) {
			setPlayerPosition(new Point(getPlayerPosition().x, getPlayerPosition().y + 5));
		}
	}

	/**
	 * modes the player left by 5 units
	 */
	@Override
	public void moveLeft() {
		if (getPlayerPosition().x - 10 > 0) {
			setPlayerPosition(new Point(getPlayerPosition().x - 5, getPlayerPosition().y));
		}
	}

	/**
	 * moves the player right by 5 units
	 */
	@Override
	public void moveRight() {
		if (getPlayerPosition().x + 50 < 600) {
			setPlayerPosition(new Point(getPlayerPosition().x + 5, getPlayerPosition().y));
		}
	}


	/**
	 * This function is called when the user presses the space bar
	 * key. And the ball is moved for a distance of 60 units
	 * with velocity 5.0 and acceleration 0.05
	 */
	@Override
	public void shootBall() {
		SoccerBall.getSoccerBall().moveBall(60, 5.0, 0.05);
	}

	/**
	 * This sets the initial position of the player
	 * to (500,450)
	 */
	@Override
	public void setInitialPosition() {
		setPlayerPosition(new Point(500, 450));
	}

	@Override
	public String toString() {
		return playerName + " scored " + playerStatistics.toString() + " goals";
	}
}
