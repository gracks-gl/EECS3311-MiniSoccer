package model.players;

import java.util.Iterator;

/**
 * This class implements an iterator for a collection of
 * GamePlayer objects
 */
public class PlayerCollectionIterator implements Iterator<GamePlayer>{
	
	private int noOfPlayer;

	private final PlayerCollection list;

	/**
	 * Initializes the iterator with the list
	 * which is to be iterated over
	 * @param List
	 */
	public PlayerCollectionIterator(PlayerCollection List) {
		
		this.list = List;
	}

	/**
	 *
	 * @return The gameplayer object pointed to
	 *         by the iterator and increments the iterator
	 */
	public GamePlayer next() {
		return this.list.get(noOfPlayer++);
	}

	/**
	 *
	 * @return true if there are gameplyer left to be iterated in the list
	 *         false when crossed the end of list
	 */
	public boolean hasNext() {
		boolean ans = noOfPlayer< this.list.size();
		return  ans;
	}
}