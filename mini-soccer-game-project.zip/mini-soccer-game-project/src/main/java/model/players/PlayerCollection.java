package model.players;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * This class maintains a collection of players
 */
public final class PlayerCollection implements Collection<GamePlayer>{
	
	private final List<GamePlayer> player;
	
	
	private static PlayerCollection secondCollection;
	
	public PlayerCollection() {
		player = new ArrayList<>();
	}
	

	public static PlayerCollection getInstance() {
		if(secondCollection == null) {
			secondCollection = new PlayerCollection();
		}
		secondCollection.clear();
		return secondCollection;
	}

	/**
	 *
	 * @param name
	 * @return the gameplayer from the collection which
	 *         has the same name
	 */
	public GamePlayer get(String name) {
		for(GamePlayer e : player) {
			if(e.getPlayerName() == name) return e;
		}
		return null;
	}


	/**
	 *
	 * @param player
	 * @return true if addition of the currrent player
	 * to the list is successful
	 */
	public boolean add(GamePlayer player) {
		return this.player.add(player);
	}

	/**
	 *
	 * @param index
	 * @return the gameplayer object corresponding to the given index
	 */
	public GamePlayer get(int index) {
		return this.player.get(index);
	}


	/**
	 *
	 * @return the number of gameplyers in the collection
	 */
	public int size() {
		return player.size();
	}

	/**
	 *
	 * @param player
	 * @return true after successfully removing the player from the collection
	 *         false in case of an error while removing the player
	 */
	public boolean remove(Object player) {
		return this.player.remove(player);
	}

	/**
	 * sorts the player by the statistics
	 */
	public void sort() {
		this.player.sort(null);
	}


	/**
	 *
	 * @return an array containing list of all the players in the
	 * collection
	 */
	public Object[] toArray() {
		return this.player.toArray();
	}
	

	
	public boolean contains(Object o) {
		boolean ans = this.player.contains(o);
		return  ans;
	}

	/**
	 *
	 * @return true if there is no player in the collection
	 *         false otherwise
	 */
	public boolean isEmpty() {
		return this.player.isEmpty();
	}


	/**
	 * Removes all players from the collection
	 */
	public void clear() {
		this.player.clear();
	}


	@Override
	public <T> T[] toArray(T[] a) {
		// TODO Auto-generated method stub
		return null;
	}

	public Iterator<model.players.GamePlayer> iterator() {
		// TODO Auto-generated method stub
		return new PlayerCollectionIterator(this);
	}
	
	

	@Override
	public boolean containsAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean addAll(Collection<? extends GamePlayer> c) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean removeAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean retainAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

}