package model;

/**
 * This stores the playerStatistics which
 * is used to sort a collection of players
 */
public class PlayerStatistics {
	
	private int stats = 0;
	
	
	public void setStatistics(Integer newStatistics) {
		this.stats = newStatistics;
	}
	
	
	public Integer getStatistics() {
		return this.stats;
	}
}